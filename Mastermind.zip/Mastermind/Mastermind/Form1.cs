﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;

namespace WindowsFormsApplication1
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        string s = "";
        string a;
        int n = 4;
        int brojPokusaja = 0;
        int red = 1;
        bool kraj = false;
        PictureBox[] kontrole;
        string title1 = "Mastermind";

        private void pictureBox1_Click(object sender, EventArgs e)
        {
            s += "1";
            kontrole[brojPokusaja].Image = pictureBox1.Image;
            brojPokusaja++;
            if (brojPokusaja == 4)
            {
                ZavrsiRed();
            }
            label1.Visible = false;
        }
        private void ZavrsiRed()
        {
            
                brojPokusaja = 0;
                int pravoMesto, pogresnoMesto;
                IzracunajPogotke(a, s, out pravoMesto, out pogresnoMesto);
                Crtaj(pravoMesto, pogresnoMesto);
                //novi niz kontrola
                kontrole = new PictureBox[4];
                for (int i = 0; i < 4; i++)
                {
                    kontrole[i] = new PictureBox();
                    kontrole[i].SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
                    Controls.Add(kontrole[i]);
                    kontrole[i].SetBounds(10 + 60 * i, 60 * red + 20, 41, 50);
                    kontrole[i].BackColor = Color.Silver;
                }
                red++;
                s = "";
                if ((red > 6) && (!kraj))
                {
                    MessageBox.Show("Više sreće drugi put!",title1);
                    kontrole = new PictureBox[4];
                    for (int i = 0; i < 4; i++)
                    {
                        kontrole[i] = new PictureBox();
                        kontrole[i].SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
                        Controls.Add(kontrole[i]);
                        kontrole[i].SetBounds(10 + 60 * i, 60 * 8  -20, 41, 50);
                        if (a[i] == '1')
                            kontrole[i].Image = pictureBox1.Image;
                        else if (a[i] == '2')
                            kontrole[i].Image = pictureBox2.Image;
                        else if (a[i] == '3')
                            kontrole[i].Image = pictureBox3.Image;
                        else if (a[i] == '4')
                            kontrole[i].Image = pictureBox4.Image;
                        else if (a[i] == '5')
                            kontrole[i].Image = pictureBox5.Image;
                        else if (a[i] == '6')
                            kontrole[i].Image = pictureBox6.Image;
                    }
                }
                else if (kraj)
                    MessageBox.Show("Bravo!",title1);
        }

        private void pictureBox2_Click(object sender, EventArgs e)
        {
            s += "2";
            kontrole[brojPokusaja].Image = pictureBox2.Image;
            brojPokusaja++;
            if (brojPokusaja == 4)
            {
                ZavrsiRed();
            }
            label1.Visible = false;
        }

        private void pictureBox3_Click(object sender, EventArgs e)
        {
            s += "3";
            kontrole[brojPokusaja].Image = pictureBox3.Image;
            brojPokusaja++;
            if (brojPokusaja == 4)
            {
                ZavrsiRed();
            }
            label1.Visible = false;
        }

        private void pictureBox4_Click(object sender, EventArgs e)
        {
            s += "4";
            kontrole[brojPokusaja].Image = pictureBox4.Image;
            brojPokusaja++;
            if (brojPokusaja == 4)
            {
                ZavrsiRed();
            }
            label1.Visible = false;
        }

        private void pictureBox5_Click(object sender, EventArgs e)
        {
            s += "5";
            kontrole[brojPokusaja].Image = pictureBox5.Image;
            brojPokusaja++;
            if (brojPokusaja == 4)
            {
                ZavrsiRed();
            }
            label1.Visible = false;
        }

        private void pictureBox6_Click(object sender, EventArgs e)
        {
            s += "6";
            kontrole[brojPokusaja].Image = pictureBox6.Image;
            brojPokusaja++;
            if (brojPokusaja == 4)
            {
                ZavrsiRed();
            }
            label1.Visible = false;
        }

        private void Form1_Load(object sender, EventArgs e)
        {
            kontrole = new PictureBox[4];
            for (int i = 0; i < 4; i++)
            {
                kontrole[i] = new PictureBox();
                kontrole[i].SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
                Controls.Add(kontrole[i]);
                kontrole[i].SetBounds(10 + 60 * i, 20, 50, 50);
                kontrole[i].BackColor = Color.Silver;
            }
            //generisanje niza
            Random r = new Random();
            a = "";
            for (int i = 0; i < n; i++)
            {
                a += (r.Next(6) + 1).ToString();
            }
        }

        private void IzracunajPogotke(string a, string b, out int pravo, out int pogresno)
        {
            
            bool[] ispitano;
            ispitano = new bool[n];
            pravo = 0;
            pogresno = 0;
            for (int i = 0; i < n; i++)
                ispitano[i] = false;
            for (int i = 0; i < n; i++)
            {
                if (a[i] == b[i])
                {
                    pravo++;
                    ispitano[i] = true;
                }
            }
            
            for (int i = 0; i < n; i++)
            {
                for (int j = 0; j < n; j++)
                {
                    if ((a[i] == b[j]) && (a[i]!=b[i]) && (i != j) && (!ispitano[j]))
                    {
                        pogresno++;
                        ispitano[j] = true;
                        break;
                    }
                }
            }
            if (pravo == 4)
                kraj = true;
        }
        private void Crtaj(int pravo,int pogresno)
        {
            
            PictureBox[] krugovi = new PictureBox[pravo+pogresno];
            int i = 0;
            for (; i < pravo; i++)
            {
                krugovi[i] = new PictureBox();
                Controls.Add(krugovi[i]);
                krugovi[i].SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
                krugovi[i].Image = pictureBoxCrveni.Image;
                krugovi[i].SetBounds(300 + 60 * i, 60 * (red-1) + 20, 41, 50);
            }
            int j = 0;
            for (; j < pogresno; j++)
            {
                krugovi[j] = new PictureBox();
                Controls.Add(krugovi[j]);
                krugovi[j].SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
                krugovi[j].Image = pictureBoxZuti.Image;
                krugovi[j].SetBounds(300 + 60 * (i+j), 60 * (red-1) + 20, 41, 50);
            }
        }

        private void button1_Click(object sender, EventArgs e)
        {
            Application.Restart();
        }

        private void btnCancel_Click(object sender, EventArgs e)
        {
            if (s.Length > 0)
            {
                s = s.Remove(s.Length - 1, 1);
                brojPokusaja--;
                kontrole[brojPokusaja].Image = null;
            }
            else
            {
                MessageBox.Show("Nemoguce je ponistiti ovaj potez.",title1);
            }
        }
    }
}